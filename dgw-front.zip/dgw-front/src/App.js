import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Base from './components/Base/Base';

const App=()=> {
  return (
  <div>
    <Base />
    </div>
   )
}

export default App;
